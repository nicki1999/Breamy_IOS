using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.Rendering.Universal;
using Vuforia;
using Dummiesman;


public class MyPrefabInstantiator : DefaultObserverEventHandler
{
    GameObject mMyModelObject;
    GameObject mMyModelObject2;
    //public string assetBundleUrl = "https://drive.google.com/uc?export=download&id=1DTTFil62xiMoO8At5D7ka8y8Ww0RGnNg";
    //public string assetBundleUrlMetaFile = "https://modeltarget.s3.ca-central-1.amazonaws.com/untitled2.obj.meta?response-content-disposition=inline&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEPL%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaDGNhLWNlbnRyYWwtMSJIMEYCIQC0Iwezql%2FlH%2BXgn2sGIp0QZMJ45HFO8JhyN1PZMw54eAIhAMJpi558rbQgTdJ2hZeKCaQbEW7oINhsonYorMd8Q3eKKu0CCNv%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEQABoMMzI1NzMyOTc4Njk4IgyLJyKL0DRE%2BkvgU9IqwQIWOgZNs5kvExwkJUHTrnFH6svJS8dI0Dc0Kd9M0ZXMthiZAWQ%2F3kSKiqWBmkM%2Bhze8ih8b0UwurBJEGQucBMQv9%2FXbX%2BHJybY4G5EJKXi5PskHILh8Htc0%2BrYuUkC5fTBEpjkD1kaR7s3%2FxELHptepLRAZi327ExJUwBy6L39qEMDc5SPEpmFHBBBBAp9S5upa0JjNJHgB1zGKqAzMqGG6hyLesZ4ua66Xx%2FR04vIYGc3U%2FeCiSYAkoz%2F27ExBWPSVJ9oYcz3w8qKQ3qtjeNh30Ij8omVre1WUeo4BqsWRDaZoj5v3MqsKQmezhrrw38Yy9xnTKW6OTJqkM1FLx3By7WwCKlzBRT103u7HVHxM77E3bqBkOYzDJws%2FV%2FuAgO09KrjvmBdcCEhFXyZfCrTRltzH59ulPmWexdJqMgaIij8w2KrEtQY6sgLRPgYkgmRIo3Qlsu4OQZKqLeuEMhARtX7QLJuqaAkBhQ%2BuDf2J%2F3tDg1OprEyJEIkeoNDoCGOBfH2QgLcJiuUqJP5aTj9hldk8w3ASPKa%2BJNMndHuHI5y7DYdwlIWgMftf5sA4g4rlc1UQqtloGtjXgL5979WX9bPRN0AkDDjXzVs7ijCpcSQmNFiIZiBsYDjhROCiWrNjKDeWgT6PnFg9ZmIKHuWL7jDoyvAzKhXsIN4%2Bb2m%2B%2FlMd6Bli1lqXSvVYChJ8t4ULQeUBPiS5p2BEi7jq268zrllfqLws8N3WRv3HjQ%2FO3l7Iz9gxFNald4zTwmlLnNfyBvjgvKb5VJI0rIbMW5kjf0Kv6KiDymIy1l1SSsqwezHVF%2B%2BOVvsECBFQx9YjzD%2BjsDvrEIecC2fe5yY%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20240805T181048Z&X-Amz-SignedHeaders=host&X-Amz-Expires=43200&X-Amz-Credential=ASIAUXVZS2AFHFGZ2YNV%2F20240805%2Fca-central-1%2Fs3%2Faws4_request&X-Amz-Signature=159303b1c9578f2c7d5b7218bf43898ff763ea086eab7d85d6744134f1442ffb";
    //public string assetName = "model38ab";
    public GameObject cubePrefab = null;
    private GameObject downloadedMesh;

    protected override void OnTrackingFound()
    {
        Debug.Log("Persistent path: " + Application.persistentDataPath);
        Debug.Log("Target Found");

        if (mMyModelObject == null)
        {
            //if (downloadedMesh == null)
            //{
            //    StartCoroutine(DownloadModel());
            //}
            //else
            //{
                StartCoroutine(InstantiatePrefab());
           // }
        }


        base.OnTrackingFound();
    }

    //IEnumerator InstantiatePrefabWithDelay()
    //{
    //    yield return null;
    //    yield return StartCoroutine(InstantiatePrefab());
    //}

    IEnumerator InstantiatePrefab()
    {
        yield return null;
        cubePrefab = Resources.Load<GameObject>("MyObject39");

        if (cubePrefab != null)
        {


            ModelTargetBehaviour modelTargetBehaviour = GetComponent<ModelTargetBehaviour>();

            //GameObject cubePrefab = Resources.Load<GameObject>("Prefabs/Cube");
            GameObject decalPrefab = Resources.Load<GameObject>("Decal Projector");
            if (cubePrefab != null && decalPrefab != null)
            {
                Debug.Log("Target found, adding content");
                mMyModelObject = Instantiate(cubePrefab, mObserverBehaviour.transform);
                mMyModelObject2 = Instantiate(decalPrefab, mObserverBehaviour.transform);
                mMyModelObject.AddComponent<PositionProjector>();

                //Debug.Log("This is the OLD local scale:" + mMyModelObject.transform.localScale);
                //// Set the scale of the instantiated object
                mMyModelObject.transform.localScale = new Vector3(1f, 1f, 1f);
                mMyModelObject2.transform.localScale = new Vector3(1f, 1f, 1f);

                //Debug.Log("This is the NEW local scale:" + mMyModelObject.transform.localScale);


                mMyModelObject.SetActive(true);
                mMyModelObject2.SetActive(true);
                Transform projector = cubePrefab.transform.Find("Decal Projector");
                if (projector != null)
                {
                    DecalProjector projectorComponent = projector.GetComponent<DecalProjector>();
                    Texture texture = projectorComponent.material.GetTexture("Base_Map");
                    Debug.Log("InstantiatePrefab MATERIAL IS: " + texture?.name);
                }
                else
                {
                    Debug.LogError("PROJECTOR IS NULL");
                }
            }
            else
            {
                Debug.LogError("Cube prefab OR decalProjector not found in directory");
            }

            ModelTargetBehaviour modelTarget = modelTargetBehaviour;
            modelTarget.enabled = false;
            Vector3 currentSize = modelTarget.GetSize();
            Debug.Log("This is the OLD local scale:" + modelTarget.transform.localScale);

            Debug.Log("Current Model target size: " + currentSize.ToString("0.000"));
            //modelTarget.SetWidth(0.533f);   // Replace with actual width in meters
            //modelTarget.SetLength(0.640f);  // Replace with actual length in meters
            //modelTarget.SetHeight(0.278f);  // Replace with actual height in meters
            //Debug.Log("Changed Model Target size to: " + modelTarget.GetSize().ToString("0.000"));
            modelTarget.transform.localScale = new Vector3(1f, 1f, 1f);
            Debug.Log("This is the NEW local scale:" + modelTarget.transform.localScale);
            modelTarget.enabled = true;
        }
        else
        {
            Debug.LogError("Cube prefab not created. Ensure model was downloaded successfully.");
        }
    }

    //IEnumerator DownloadModel()
    //{
    //    //using (UnityWebRequest www = UnityWebRequest.Get(assetBundleUrlMetaFile))
    //    //{
    //    //    yield return www.SendWebRequest();

    //    //    if (www.result == UnityWebRequest.Result.Success)
    //    //    {
    //    //        Debug.Log("Meta file downloaded");

    //    //        string path = Path.Combine(Application.persistentDataPath, "untitled2.obj.meta");
    //    //        File.WriteAllText(path, www.downloadHandler.text);

    //    //    }
    //    //    else
    //    //    {
    //    //        Debug.LogError("Failed to download .META file: " + www.error);
    //    //    }
    //    //}
    //    using (UnityWebRequest www = UnityWebRequest.Get(assetBundleUrl))
    //    {
    //        yield return www.SendWebRequest();

    //        if (www.result == UnityWebRequest.Result.Success)
    //        {
    //            Debug.Log("Model downloaded");

    //            //string path = Path.Combine(Application.persistentDataPath, "Cube.prefab");
    //            //string mtlPath = Path.Combine(Application.persistentDataPath, "untitled2.mtl");
    //            //File.WriteAllText(path, www.downloadHandler.text);
    //            //string fileContent = File.ReadAllText(path);
    //            ////Debug.Log("File content: " + fileContent);

    //            //if (File.Exists(mtlPath))
    //            //{
    //            //    File.Delete(mtlPath);
    //            //}
    //            ////GameObject loadedObj = new OBJLoader().Load(path, mtlPath);
    //            ////Destroy(loadedObj);
    //            ////cubePrefab = loadedObj;
    //            ////cubePrefab = Resources.Load<GameObject>("Prefabs/Cube");


    //            //string objData = www.downloadHandler.text;
    //            //downloadedMesh = ParseObj(objData);
    //            //if (downloadedMesh != null)
    //            //{
    //            //    cubePrefab = new GameObject("CubePrefab");
    //            //    MeshFilter meshFilter = cubePrefab.AddComponent<MeshFilter>();
    //            //    MeshRenderer meshRenderer = cubePrefab.AddComponent<MeshRenderer>();

    //            //    meshFilter.mesh = downloadedMesh;
    //            //    meshRenderer.material = new Material(Shader.Find("Standard"));
    //            //    cubePrefab.SetActive(true);
    //            //    meshRenderer.enabled = true;



    //            //}
    //            if (www.result != UnityWebRequest.Result.Success)
    //            {
    //                Debug.LogError("Failed to download AssetBundle: " + www.error);
    //                yield break;
    //            }

    //            // Step 2: Load the AssetBundle
    //            AssetBundle assetBundle = AssetBundle.LoadFromMemory(www.downloadHandler.data);
    //            if (assetBundle == null)
    //            {
    //                Debug.LogError("Failed to load AssetBundle.");
    //                yield break;
    //            }

    //            // Step 3: Load the prefab from the AssetBundle
    //            downloadedMesh = assetBundle.LoadAsset<GameObject>("model38");
    //            cubePrefab = downloadedMesh;
    //            if (downloadedMesh == null)
    //            {
    //                Debug.LogError("Failed to load prefab from AssetBundle.");
    //                yield break;
    //            }
    //        }
    //            else
    //            {
    //                Debug.LogError("Failed to download .obj file: " + www.error);
    //            }
    //            StartCoroutine(InstantiatePrefab());
    //        }
    //    }

    //    Mesh ParseObj(string objData)
    //    {
    //        Mesh mesh = new Mesh();
    //        var vertices = new List<Vector3>();
    //        var triangles = new List<int>();

    //        var lines = objData.Split('\n');

    //        foreach (var line in lines)
    //        {
    //            if (string.IsNullOrWhiteSpace(line)) continue;

    //            var parts = line.Split(' ');

    //            switch (parts[0])
    //            {
    //                case "v":
    //                    if (parts.Length >= 4)
    //                    {
    //                        if (float.TryParse(parts[1], out float x) &&
    //                            float.TryParse(parts[2], out float y) &&
    //                            float.TryParse(parts[3], out float z))
    //                        {
    //                            vertices.Add(new Vector3(x, y, z));
    //                        }
    //                    }
    //                    break;

    //                case "f":
    //                    for (int i = 1; i < parts.Length; i++)
    //                    {
    //                        var indices = parts[i].Split('/');
    //                        if (int.TryParse(indices[0], out int vertexIndex))
    //                        {
    //                            triangles.Add(vertexIndex - 1);
    //                        }
    //                    }
    //                    break;
    //            }
    //        }

    //        mesh.vertices = vertices.ToArray();
    //        mesh.triangles = triangles.ToArray();
    //        mesh.RecalculateNormals();

    //        return mesh;
    //    }
    }
