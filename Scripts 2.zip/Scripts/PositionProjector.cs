using UnityEngine;

public class PositionProjector : MonoBehaviour
{
    public string decalProjectorName = "Decal Projector(Clone)";
    //public string submeshName = "default";
    void Start()
    {
        CenterProjector();
    }

    void CenterProjector()
    {
        Debug.Log("PositionProjector started");
        // The GameObject this script is attached to is the target model
        GameObject targetModel = gameObject;

        // Find the Decal Projector sibling by name
        Transform parentTransform = targetModel.transform.parent;
        if (parentTransform == null)
        {
            Debug.LogWarning("The target model does not have a parent.");
            return;
        }


        Transform decalTransform = parentTransform.Find(decalProjectorName);
        if (decalTransform == null)
        {
            Debug.LogWarning($"Decal Projector with name '{decalProjectorName}' not found.");
            return;
        }
        Debug.Log("FINISHED THIS PHASE");

        GameObject decalProjector = decalTransform.gameObject;
        Transform submeshTransform = targetModel.transform.GetChild(0);


        // Get the MeshRenderer component of the target model
        MeshRenderer meshRenderer = submeshTransform.GetComponent<MeshRenderer>();
        if (meshRenderer != null)
        {
            // Calculate the bounds of the mesh
            Bounds bounds = meshRenderer.bounds;
            Vector3 modelCenter = bounds.center;
            Debug.Log("modelCenter: " + modelCenter);

            // Position the Decal Projector at the center of the mesh bounds
            decalProjector.transform.position = modelCenter;

            // Adjust the rotation to ensure it faces the model correctly
            // Assuming you want the projector to face towards the front of the model
            decalProjector.transform.rotation = Quaternion.LookRotation(-targetModel.transform.forward);

            // Optionally adjust the size of the Decal Projector to fit the mesh bounds
            // Adjust the size based on your needs
            // e.g., decalProjector.transform.localScale = new Vector3(bounds.size.x, bounds.size.y, bounds.size.z);
        }
        else
        {
            Debug.LogWarning("MeshRenderer component not found on the target model.");
        }
    }

}
